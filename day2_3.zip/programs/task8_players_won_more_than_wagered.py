import csv

input_file = "casino_gambling_data_enhanced.csv"

print("Players who won more than they wagered:")

with open(input_file, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        try:
            won = float(row['AmountWon'])
            wagered = float(row['AmountWagered'])
            if won > wagered:
                print(f"{row['PlayerName']} - Won: ₹{won}, Wagered: ₹{wagered}")
        except ValueError:
            continue
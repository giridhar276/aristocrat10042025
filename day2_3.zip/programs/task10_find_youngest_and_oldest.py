import csv

file_path = "casino_gambling_data_enhanced.csv"

min_age = 999
max_age = -1
youngest = None
oldest = None

with open(file_path, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        try:
            age = int(row['Age'])
            if age < min_age:
                min_age = age
                youngest = row['PlayerName']
            if age > max_age:
                max_age = age
                oldest = row['PlayerName']
        except ValueError:
            continue

print(f"Youngest player: {youngest} ({min_age} years)")
print(f"Oldest player: {oldest} ({max_age} years)")
import csv
from collections import Counter

# Load the CSV
file_path = "casino_gambling_data_enhanced.csv"
gender_count = Counter()

with open(file_path, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        gender = row['Gender']
        gender_count[gender] += 1

print("Player count by gender:")
for gender, count in gender_count.items():
    print(f"{gender}: {count}")
########################################
#Parse and Print All Employee Names
########################################
import xml.etree.ElementTree as ET

tree = ET.parse('employees.xml')
root = tree.getroot()

for emp in root.findall('employee'):
    name = emp.find('name').text
    print("Employee Name:", name)

########################################
#Example 2: Extract Employee Info into Dictionary
########################################
import xml.etree.ElementTree as ET

tree = ET.parse('employees.xml')
root = tree.getroot()

employees = []

for emp in root.findall('employee'):
    emp_data = {
        'id': emp.find('id').text,
        'name': emp.find('name').text,
        'age': int(emp.find('age').text),
        'department': emp.find('department').text
    }
    employees.append(emp_data)

print(employees)

########################################
#Find Employees in a Specific Department
########################################
dept_name = 'Finance'

for emp in root.findall('employee'):
    if emp.find('department').text == dept_name:
        print(emp.find('name').text)

########################################
# Add a New Employee to XML
########################################
new_emp = ET.Element("employee")
ET.SubElement(new_emp, "id").text = "103"
ET.SubElement(new_emp, "name").text = "Alice Brown"
ET.SubElement(new_emp, "age").text = "25"
ET.SubElement(new_emp, "department").text = "IT"

root.append(new_emp)
tree.write("employees_updated.xml")

########################################
#Delete an Employee by ID
########################################
for emp in root.findall('employee'):
    if emp.find('id').text == '101':
        root.remove(emp)

tree.write("employees_deleted.xml")
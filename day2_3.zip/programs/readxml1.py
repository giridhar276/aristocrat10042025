import xml.etree.ElementTree as ET

tree = ET.parse('employees.xml')
root = tree.getroot()

for emp in root.findall('employee'):
    name = emp.find('name').text
    print("Employee Name:", name)
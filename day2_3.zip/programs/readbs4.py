

import requests
from bs4 import BeautifulSoup

response =requests.get("https://www.wikipedia.org/")
if response.status_code == 200:
    content = response.text
    #print(content)  # content is html content
    soup = BeautifulSoup(content, 'html.parser')
    for link in soup.find_all('a'):
        print(link.get('href'))
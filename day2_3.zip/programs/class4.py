
import os

class FileOperations:
    def __init__(self,filename):
        self.filename = filename
    def readFile(self):
        try:
            if os.path.isfile(self.filename):
                with open(self.filename,"r") as self.fobj:
                    for line in self.fobj:
                        print(line)
            else:
                print("file not found")
        except Exception as err:
            print(err)

if __name__ == "__main__": # will be always True if executed directly
    myfile1 = FileOperations("employeeinfo.csv")
    myfile1.readFile()
    myfile2 = FileOperations("casino_gambling_data.csv")
    myfile2.readFile()


##### differnet ways of importing library
# method1  # preferred way
import math   # all the methods will be importing to your space
print(math.log(1))
print(math.tan(2))

# method2 - importing with alias name
# pip install matplotlib
import matplotlib.pyplot as plt
plt.plot([10,20],[30,40])
plt.show()


#method3 - we are just importing sin() and cos() methods only 
from math import sin,cos
print(sin(1))
print(cos(2))

#method4 - not much preferred
from math import *
print(sin(1))
print(cos(2))



import csv
try:
    with open("employeeinfo1.csv","r") as fobj:  # file object
        reader = csv.reader(fobj) # converting file object to csv object
        for line in reader:
            print(line)
except FileNotFoundError as err:
    print("file not found.. please check")
    print(err)
except TypeError as err:
    print("Invalid Operation")
    print(err)
except (IndexError,KeyError) as err:
    print("Index or key is not found")
    print(err)
except Exception as e:  # default exception
    print("Unknown error found")
    print(e)
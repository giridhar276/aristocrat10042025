from openpyxl import load_workbook

try:
    wb = load_workbook('employeeinfo.xlsx')
    print("Sheets in the file:", wb.sheetnames)

    ws = wb.active  # or wb['YourSheetName']

    for row in ws.iter_rows(values_only=True):
        print(row)
        ws.iter

except FileNotFoundError:
    print("File not found. Make sure 'sample.xlsx' exists in your directory.")
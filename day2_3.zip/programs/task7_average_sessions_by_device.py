import csv
from collections import defaultdict

file_path = "casino_gambling_data.csv"
device_sessions = defaultdict(lambda: {"total_sessions": 0, "count": 0})

with open(file_path, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        device = row['DeviceUsed']
        try:
            sessions = int(row['SessionCount'])
            device_sessions[device]["total_sessions"] += sessions
            device_sessions[device]["count"] += 1
        except ValueError:
            continue

print("Average session count by device type:")
for device, data in device_sessions.items():
    avg = data["total_sessions"] / data["count"] if data["count"] > 0 else 0
    print(f"{device}: {avg:.2f}")

#Reading CSV (As List of Lists)
import csv
with open('employeeinfo.csv', mode='r', newline='') as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)



#Reading CSV (Line by Line as Dictionary)
import csv
with open('employeeinfo.csv', mode='r', newline='') as file:
    reader = csv.DictReader(file)
    for row in reader:
        print(row)


# writing to csv
new_employee = ["Robert", 45, "Legal"]
with open('employeeinfo.csv', mode='a', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(new_employee)


    

#Writing to CSV (New File with Headers)
data = [
    {"Name": "John Doe", "Age": 28, "Department": "HR"},
    {"Name": "Jane Smith", "Age": 32, "Department": "Finance"},
]

with open('new_employee_data.csv', mode='w', newline='') as file:
    fieldnames = ["Name", "Age", "Department"]
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    for emp in data:
        writer.writerow(emp)

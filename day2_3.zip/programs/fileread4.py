
#Count the occurrences of each game type found in the GamePlayed column and print the results.


import csv
from collections import Counter

input_file = "casino_gambling_data.csv"

game_counts = Counter()

with open(input_file, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        game = row['GamePlayed']
        game_counts[game] += 1

print("Game Preferences Count:")
for game, count in game_counts.most_common():
    print(f"{game}: {count}")
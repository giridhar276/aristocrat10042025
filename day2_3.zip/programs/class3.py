

class Employee:
    #constructor
    #constructor is invoked automatically when object is created
    def __init__(self,name,city):
        self.name = name  #emp1.name = "rita"
        self.city = city  #emp1.city = "mum"
    def displayDetails(self):
        print("Name :",self.name)
        print("City :",self.city)

 
emp1 = Employee("Rita","Mumbai") # object creation
emp1.displayDetails()             # display name


emp2 = Employee("gita","Delhi")
emp2.displayDetails()
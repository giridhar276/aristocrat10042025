import re
import csv

def is_valid_email(email):
    return re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email)

def read_emails_from_csv(filename):
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        emails = [row[1] for row in reader]  # assuming 2nd column is email
    return emails

def clean_emails(emails):
    return list(filter(lambda email: is_valid_email(email), emails))

emails = read_emails_from_csv("users.csv")
valid = clean_emails(emails)
print(valid)
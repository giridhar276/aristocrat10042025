import zipfile
import os

def zip_text_files(folder_path, zip_name):
    try:
        with zipfile.ZipFile(zip_name, 'w') as zipf:
            for file in os.listdir(folder_path):
                if file.endswith('.txt'):
                    zipf.write(os.path.join(folder_path, file), arcname=file)
        print(f"[INFO] Created zip file: {zip_name}")
    except Exception as e:
        print(f"[ERROR] {e}")

zip_text_files("./data", "backup_text_files.zip")
def square(x): return x * x
def cube(x): return x * x * x

def menu():
    try:
        choice = int(input("Choose:\n1. Square\n2. Cube\n> "))
        numbers = list(map(int, input("Enter numbers (comma separated): ").split(',')))
        func = square if choice == 1 else cube
        result = list(map(func, numbers))
        print("Result:", result)
    except Exception as e:
        print("[ERROR]", e)

menu()
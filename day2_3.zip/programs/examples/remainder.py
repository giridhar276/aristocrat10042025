from datetime import datetime

def remind_task(task_name, due_date_str):
    due_date = datetime.strptime(due_date_str, "%Y-%m-%d")
    days_left = (due_date - datetime.today()).days
    if days_left >= 0:
        print(f"Task '{task_name}' is due in {days_left} day(s).")
    else:
        print(f"Task '{task_name}' is overdue by {-days_left} day(s).")


remind_task("Project Submission", "2025-04-15")
from collections import Counter

def count_words(filename):
    try:
        with open(filename, 'r') as f:
            words = f.read().lower().split()
            word_counts = Counter(words)
            return word_counts.most_common(5)
    except FileNotFoundError:
        print("[ERROR] File not found.")

print(count_words("sample.txt"))
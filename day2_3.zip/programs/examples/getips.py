import socket

def get_ip(domain):
    try:
        return socket.gethostbyname(domain)
    except Exception:
        return "Invalid"

def process_domains(file):
    with open(file, 'r') as f:
        domains = f.read().splitlines()
    return dict(map(lambda d: (d, get_ip(d)), domains))

print(process_domains("domains.txt"))
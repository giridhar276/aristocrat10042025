import os

def rename_files_in_folder(folder_path, prefix="file"):
    try:
        files = os.listdir(folder_path)
        for idx, filename in enumerate(files):
            old_path = os.path.join(folder_path, filename)
            ext = os.path.splitext(filename)[1]
            new_path = os.path.join(folder_path, f"{prefix}_{idx+1}{ext}")
            os.rename(old_path, new_path)
        print(f"[INFO] Renamed {len(files)} files successfully.")
    except Exception as e:
        print(f"[ERROR] {e}")

rename_files_in_folder("path_to_folder", "image")
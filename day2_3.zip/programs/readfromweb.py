
import csv
from io import StringIO
import requests

# URL of the CSV file hosted on GitHub
url = "https://raw.githubusercontent.com/giridhar276/aristocrat10042025/refs/heads/main/employeeinfo.csv"

# Step 1: Download the CSV content
response = requests.get(url)
if response.status_code == 200:
    # Step 2: Parse CSV using csv module
    #converting text stream using StringIO method (an in-memory text buffer)
    csv_data = StringIO(response.text)   
    reader = csv.DictReader(csv_data)
    for record in reader:
        print(record)


### using pandas
import pandas as pd
df = pd.read_csv(url)
print(df['workclass'].unique())

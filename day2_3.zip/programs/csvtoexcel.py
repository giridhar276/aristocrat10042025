

from openpyxl import Workbook
import csv
import time
try:
    filename = time.strftime("%d_%b_%Y_%H_%M_%S.xlsx") #11_Apr_2025.xlsx
    wb = Workbook() # creating workbook
    # grab the active worksheet
    ws = wb.active
    with open("employeeinfo.csv") as fobj:
        reader = csv.reader(fobj)
        for line in reader:
            #print(line)
            ws.append(line)
    wb.save(filename)
except Exception as err:
    print(err)

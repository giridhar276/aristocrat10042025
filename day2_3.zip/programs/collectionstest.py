#Used for counting hashable objects.
from collections import Counter

data = ['apple', 'banana', 'apple', 'orange', 'banana', 'apple']
counter = Counter(data)
print(counter)


#Provides a default value for a key that doesn't exist.
from collections import defaultdict

d = defaultdict(int)
for item in ['a', 'b', 'a', 'c', 'b']:
    d[item] += 1

print(d)


#Preserves the order in which keys are inserted.
from collections import OrderedDict

od = OrderedDict()
od['apple'] = 3
od['banana'] = 1
od['orange'] = 2

print(od) 




#Double-ended queue for fast appends and pops from both ends.
from collections import deque

d = deque()
d.append('a')
d.append('b')
d.appendleft('z')
print(d)  # Output: deque(['z', 'a', 'b'])
d.pop()   # Removes 'b'
d.popleft()  # Removes 'z'
print(d)
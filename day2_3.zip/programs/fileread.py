# reading the file line by line
# fobj acts like cursor for navigation
with open("languages.csv","r") as fobj:
    for line in fobj:
        print(line.strip())

# reading using fobj.readlines() - in list object
with open("languages.csv","r") as fobj:
    print(fobj.readlines())

with open("languages.csv","r") as fobj:
    for line in fobj.readlines():
        print(line)

# using fobj.read()  - everything will be displayed in a single string
with open("languages.csv","r") as fobj:
    print(fobj.read())  # ctrl A + ctrl V

# using csv library ( most preferred one)
import csv
with open("languages.csv","r") as fobj:
    reader = csv.reader(fobj)  # file object is converted to csv object
    for line in reader:
        print(line)

# if we have huge volume of data available, using pandas is preferred way
import pandas  # third party library
df = pandas.read_csv("languages.csv",header=1)
print(df)
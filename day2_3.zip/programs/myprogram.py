

import allfunctions

allfunctions.displayname()
allfunctions.displaycity()








import csv
try:
    worklist = []
    with open("employeeinfo.csv","r") as fobj:  # file object
        header = fobj.readline() # reading header to object
        reader = csv.reader(fobj) # converting file object to csv object
        # processing
        for line in reader:
            workclass = line[1]
            worklist.append(workclass)
        # display output
        for item in set(worklist):
            print(item)
except FileNotFoundError as err:
    print("file not found.. please check")
    print(err)
except TypeError as err:
    print("Invalid Operation")
    print(err)
except (IndexError,KeyError) as err:
    print("Index or key is not found")
    print(err)
except Exception as e:  # default exception
    print("Unknown error found")
    print(e)








import csv
try:
    workdict = dict()
    with open("employeeinfo.csv","r") as fobj:  # file object
        header = fobj.readline() # reading header to object
        reader = csv.reader(fobj) # converting file object to csv object
        # processing
        for line in reader:
            workclass = line[1]
            workdict[workclass] =1  # {"Private":1 ,"Public":1}
        # display output
        for item in workdict.keys():
            print(item)
except FileNotFoundError as err:
    print("file not found.. please check")
    print(err)
except TypeError as err:
    print("Invalid Operation")
    print(err)
except (IndexError,KeyError) as err:
    print("Index or key is not found")
    print(err)
except Exception as e:  # default exception
    print("Unknown error found")
    print(e)
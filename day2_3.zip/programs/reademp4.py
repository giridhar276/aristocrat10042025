
import csv
try:
    mcount = 0
    fcount = 0
    with open("employeeinfo.csv","r") as fobj:  # file object
        header = fobj.readline() # reading header to object
        reader = csv.reader(fobj) # converting file object to csv object
        # processing
        for line in reader:
            gender = line[9].strip()
            if gender == "Male":
                mcount = mcount + 1
            if gender == "Female":
                fcount = fcount + 1
        print("Male count  :", mcount)
        print("Female count:",fcount)
except FileNotFoundError as err:
    print("file not found.. please check")
    print(err)
except TypeError as err:
    print("Invalid Operation")
    print(err)
except (IndexError,KeyError) as err:
    print("Index or key is not found")
    print(err)
except Exception as e:  # default exception
    print("Unknown error found")
    print(e)
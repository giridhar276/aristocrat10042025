import requests
try:
    with open("companies.txt") as fobj:
        for line in fobj:
            url = line.strip()
            response = requests.get(url)
            #print(response.status_code)
            if response.status_code == 200 :
                print(url,"is up")
            else:
                print(url,"is down")
except Exception as err:
    print(err)
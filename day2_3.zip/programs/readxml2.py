import xml.etree.ElementTree as ET

tree = ET.parse('employees.xml')
root = tree.getroot()

employees = []

for emp in root.findall('employee'):
    emp_data = {
        'id': emp.find('id').text,
        'name': emp.find('name').text,
        'age': int(emp.find('age').text),
        'department': emp.find('department').text
    }
    employees.append(emp_data)

print(employees)


class Employee:
    def displayEmployee(self):
        print("Employee name :","rita")



emp1 = Employee()         # aset = set()     
emp1.displayEmployee()

emp2 = Employee()        
emp2.displayEmployee()


emp3 = Employee()        
emp3.displayEmployee()



 
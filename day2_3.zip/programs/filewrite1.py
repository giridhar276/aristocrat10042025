
# pythonic way
# context manager
# If any line starts with keyword with ... we call it context manager
# Advantage : file will be closed automatically
# when the control is out of indentation .. file will be closed automatically

with open("data.txt","w") as fobj:
    fobj.write("python programming\n")
    fobj.write("java\n")
    for val in range(1,10):
        fobj.write(str(val) + "\n")
    # end of file writing






def displayname():
    print("Name :","ram")

def displayage():
    print("Age:",29)

def displaycity():
    print("city :","mumbai")

# if this program is executed directly the below condition is True
# if this program is imported to other program ... below condition becomes False
if __name__ == "__main__":
    displayname()
    displayage()
    displaycity()
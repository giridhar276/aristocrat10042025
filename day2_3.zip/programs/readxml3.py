import xml.etree.ElementTree as ET

tree = ET.parse('employees.xml')
root = tree.getroot()

employees = []

dept_name = 'Finance'

for emp in root.findall('employee'):
    if emp.find('department').text == dept_name:
        print(emp.find('name').text)
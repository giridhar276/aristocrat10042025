

#CASE1: If the file is not existing.. file will be created first
#CASE2: If the file is already exists.. it overwrites everything and starts from beginning

# if the file has to be created in different path .. use one of the below
#open(r"C:\\new\\new\\new\\data.txt","w") 
#fobj = open("C:\\Desktop\\data.txt","w")
#fobj = open("C:/Desktop/data.txt","w")
#fobj = open(r"C:\Desktop\data.txt","w")  # raw string

# traditional way 
fobj = open("data.txt","w")

fobj.write("python programming\n")
fobj.write("java\n")
alist = ["unix","java","oracle"]
newlist = list(map(lambda x : x + "\n", alist))  #["unix\n","java\n"]
fobj.writelines(newlist)

for val in range(1,10):
    fobj.write(str(val) + "\n")

fobj.close()
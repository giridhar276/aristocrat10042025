
#ead the CSV file and calculate summary statistics (minimum, maximum, average) for numerical columns: Age, AmountWagered, AmountWon, and SessionCount.
import csv

file_path = "casino_gambling_data.csv"

# Define columns to analyze
numeric_columns = ['Age', 'AmountWagered', 'AmountWon', 'SessionCount']

# Prepare a dictionary to store summary statistics
summary_stats = {col: [] for col in numeric_columns}

with open(file_path, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        for col in numeric_columns:
            try:
                # Convert to float (or int) and add to list
                summary_stats[col].append(float(row[col]))
            except ValueError:
                pass

# Compute statistics
print("Summary Statistics:")
for col in numeric_columns:
    values = summary_stats[col]
    min_val = min(values)
    max_val = max(values)
    avg_val = sum(values) / len(values)
    print(f"{col}: min = {min_val}, max = {max_val}, avg = {avg_val:.2f}")
import os
import re
import json
from datetime import datetime

# --------------------------
# Step 1: Create a sample data file (file handling - write)
# --------------------------
def create_sample_file(filename):
    users = [
        "Alice,alice@example.com,1990-05-14",
        "Bob,bob@sample,1988-07-32",  # Invalid email and date
        "Charlie,charlie@example.com,1993-09-10",
        "Dana,dana@example.org,2001-13-01",  # Invalid month
        "Eve,eve123@domain.com,1999-02-28"
    ]
    with open(filename, 'w') as f:
        for user in users:
            f.write(user + '\n')
    print(f"[INFO] Sample data written to {filename}")


# --------------------------
# Step 2: Validate email and date using regex and datetime
# --------------------------
def is_valid_email(email):
    return re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email)

def is_valid_date(date_str):
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False


# --------------------------
# Step 3: Process the file (file handling - read, map/filter/lambda)
# --------------------------
def process_user_file(filename):
    valid_users = []
    try:
        with open(filename, 'r') as f:
            lines = f.readlines()
        
        for line in lines:
            name, email, dob = map(str.strip, line.strip().split(','))
            if is_valid_email(email) and is_valid_date(dob):
                age = calculate_age(dob)
                valid_users.append({
                    "name": name.title(),
                    "email": email.lower(),
                    "dob": dob,
                    "age": age
                })
    except FileNotFoundError:
        print(f"[ERROR] File '{filename}' not found.")
    except Exception as e:
        print(f"[ERROR] Unexpected error: {e}")
    return valid_users


# --------------------------
# Step 4: Calculate Age (user-defined function)
# --------------------------
def calculate_age(dob_str):
    dob = datetime.strptime(dob_str, "%Y-%m-%d")
    today = datetime.today()
    return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))


# --------------------------
# Step 5: Filter adults (using filter + lambda)
# --------------------------
def filter_adults(users):
    return list(filter(lambda u: u['age'] >= 18, users))


# --------------------------
# Step 6: Export as JSON (file handling + automation use-case)
# --------------------------
def export_to_json(data, filename):
    try:
        with open(filename, 'w') as f:
            json.dump(data, f, indent=4)
        print(f"[INFO] Valid adult users exported to {filename}")
    except Exception as e:
        print(f"[ERROR] Failed to export data: {e}")


# --------------------------
# Main automation flow
# --------------------------
def main():
    input_file = "users.txt"
    output_file = "valid_adults.json"
    
    create_sample_file(input_file)
    users = process_user_file(input_file)
    
    print(f"[INFO] Total valid users: {len(users)}")
    adults = filter_adults(users)
    
    print(f"[INFO] Adult users (age >= 18): {len(adults)}")
    export_to_json(adults, output_file)


if __name__ == "__main__":
    main()
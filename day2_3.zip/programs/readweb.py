

import requests

url = "https://raw.githubusercontent.com/giridhar276/aristocrat10042025/refs/heads/main/employeeinfo.csv"

response = requests.get(url)
#print(response.status_code)
if response.status_code == 200:
    print(response.text)

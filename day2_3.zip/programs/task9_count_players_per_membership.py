import csv
from collections import Counter

file_path = "casino_gambling_data_enhanced.csv"
membership_count = Counter()

with open(file_path, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        membership = row['MembershipLevel']
        membership_count[membership] += 1

print("Player count by Membership Level:")
for level, count in membership_count.items():
    print(f"{level}: {count}")
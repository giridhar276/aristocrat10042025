
#Filter and save records where AmountWagered is more than 5000 and SessionCount is greater than 10.

import csv

input_file = "casino_gambling_data.csv"
output_file = "high_rollers_manual.csv"

high_rollers = []

with open(input_file, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    header = reader.fieldnames
    for row in reader:
        try:
            wagered = float(row['AmountWagered'])
            sessions = int(row['SessionCount'])
            if wagered > 5000 and sessions > 10:
                high_rollers.append(row)
        except ValueError:
            continue

# Write the filtered records to a new CSV file
with open(output_file, "w", newline='', encoding='utf-8') as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=header)
    writer.writeheader()
    writer.writerows(high_rollers)

print(f"Filtered high rollers have been saved to {output_file}")
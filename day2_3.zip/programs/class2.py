

class Employee:
    def getDetails(self,name,city):
        self.name = name  #emp1.name = "rita"
        self.city = city  #emp1.city = "mum"
    def displayDetails(self):
        print("Name :",self.name)
        print("City :",self.city)

emp1 = Employee()
emp1.getDetails("Rita","Mumbai")  # setting name
emp1.displayDetails()             # display name


emp2 = Employee()
emp2.getDetails("gita","Delhi")
emp2.displayDetails()
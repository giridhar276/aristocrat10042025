

# traditional way
def display(a,b):
    c = a + b
    return c
# calling function
total = display(10,20)
print(total)


#lambda function
# lambda is the replacement of single liner function
# Advantage : expression will be replaced in the calling function body internally
# faster execution
#syntax
#functioname = lambda variables: expression
display = lambda a,b : a + b
# calling function
total = display(10,20)
print(total)


display = lambda *args : sum(args)
# calling function
total = display(10,20,30,40,50,60,60,70,80,80,90,100)
print(total)


display = lambda x : "positive" if x > 0 else "negative"
output = display(5)
print(output)


checkupper = lambda x: "upper" if x.isupper() else "lower"
status = checkupper("python")
print(status)


alist = [10,20,30,40]
# write a program to display the below outoput
#[15,25,35,45]

# method1
alist = [10,20,30,40]
blist = []
for val in alist:
    blist.append(val + 5)
print(blist)

# method2  - using map(function,iterable)
def increment(x):
    return x+5
# map(function,iterable)
print(list(map(increment,alist)))

#method3  -  using map with lambda
increment = lambda x: x+5
# map(function,iterable)
print(list(map(increment,alist)))

## writing in single line
print(list(map(lambda x: x+5,alist)))
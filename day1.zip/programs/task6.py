'''
write a program to display the below IP addresses

192.168.0.1
192.168.0.2
192.168.0.3
..
..
192.168.0.10
'''

name = "I love {} and {}"  # template
print(name.format("python","c"))
print(name.format("hyderabad","delhi"))

# method1
fixed = "192.168.0.{}"
for val in range(1,11):
    print(fixed.format(val))


#method2
fixed = "192.168.0."
for val in range(1,11):
    ip = fixed + str(val)
    print(ip)



# function body  ## fixed arguments
def display(a,b):
    c = a + b
    return c
# calling function
total = display(10,20)
print(total)

# default arguments
def display(a = 0,b = 0,c = 0):
    print(a,b,c)
display()
display(10)
display(10,20)
display(10,20,30)

# keyword arguments
def display(b,a,c):
    print(a,b,c) # 10 20 30
display(c=30,a=10,b=20)

#variable length arguments
def display(*args):
    print(type(args))
    for val in args:
        print(val)

display(10,20,30,40,5067,4,6,4,56,43,67,32,567,3,6,43,67,3,56,43,0,"java")

def displayinfo(**kwargs):
    for key,value in kwargs.items():
        print(key,value)

displayinfo(chap1=10,chap2=20)
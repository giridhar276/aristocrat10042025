
book = {"chap1":10 , "chap2":20 , "chap3":30, "chap1":100 }
print(book)


# add new key-value pair
book["chap1"] = 40
book["chap5"] = 50
print(book)
# display individual value
print(book["chap1"])
print(book["chap2"])

# display key only
print(book.keys())

for key in book.keys():
    print(key)

# display values only
print(book.values())

for value in book.values():
    print(value)

# display key-value pair line by line
print(book.items())

for key,value in book.items():
    print(key,value)



book = {"chap1":10 , "chap2":20 , "chap3":30}
newbook = {"chap8":80,"chap9":90}

# method1
finalbook = {book,newbook}
print(finalbook)

# method2
book.update(newbook)
print(book)

alist= [10,20,30]
blist = [40,50,60]
finallist = alist + blist
print(finallist)

str1 = "python"
str2 = "programming"
finalstr = str1 + str2
print(finalstr)
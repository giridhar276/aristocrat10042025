name = "python programming"
print("I love", name)
# string[start:stop:step]
print(name[0])
print(name[1])
print(name[0:9])
print(name[7:11])
print(name[0:9:1])   #print(name[0:9])  are same.
print(name[0:9:2])
print(name[9:16:3])
print(name[-1])
print(name[-4:-6])
print(name[:])       # print(name)  #everything
print(name[::])      #print(name[0:18:1])
print(name[::1])
print("total no. of characters :", len(name))
#p  y   t   h   o  n       p    r    o     g     r    a    m   m    i   n    g
#0  1   2   3   4  5   6   7    8    9    10    11   12   13   14  15  16   17
#                                                             -4   -3  -2   -1


name = "python programming"
print(name.capitalize())
print(name.title())
print(name.upper())
print(name)    # willr remain name
print(name.center(40))
print(name.center(40,"*"))
print(name.replace("python","scala"))
print(name.count("p"))
print(name.count("Z"))
print(name.find("gr"))  # will return starting index of g
print(name.find("z"))   # -1 if substring not found
print(name.isupper())
print(name.islower())
print(name.isalpha())
print(name.isalnum())

aname = " python  "
print(len(aname))
print(len(aname.strip())) # will remove whitespaces at both the ends
print(len(aname.lstrip()))
print(len(aname.rstrip()))


if 1 < 2 :
    print("1 < 2")
    print("inside if")
    print("still inside if")
    print("Still inside if only")
print("out if condition")

if name.isupper():
    print("string is upper")
else:
    print("string is lower")

if name.startswith("p"):
    print("Its python programming")
else:
    print("its someother language")

name = "python"
if 'th' in name:
    print("Substring exists")
else:
    print("substring not found")

# range(start,stop,step)
for val in range(1,11):
    print(val)
#### reverve order
for i in range(10,0,-1):
    print(i)
# reading each character
name = "python"
for char in name :
    print(char)

alist = [10,20,30]
for value in alist:
    print(value)


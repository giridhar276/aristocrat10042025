print("python programming")

alist = [10,20,30]
alist[0] = 100
print(alist)

atup = (10,20,30)
temp = list(atup)   # typecasting: converting from one object to another object
temp[0]  = 100      # now making the change
atup = tuple(temp)  # converting back to tuple
#atup[0] = 100
print(atup)

aset = {10,10,20,20,30}
print(aset)


val = 10
print(val++)


alist = [45,56,3,67,32,67,3]
alist.append(100)      # add single value
print("After appending :", alist)
alist.extend([46,93,45]) # add multiple values
print("After extending :",alist)
alist.insert(1,200)      # list.insert(index, value)
print("After inserting :",alist)
alist.pop(2)  #alist.pop(index)      # 2 is the index  #value at index2 will be removed
print(alist)

val = 101
if val in alist:
    alist.remove(val)    #list.remove(value)  # value will removed
    print("after removing :", alist)
else:
    print(val, " not found in the list")

alist.sort()
print("After sorting :", alist)
alist.sort(reverse=True)
print("After sorting :", alist)
alist.reverse()
print("AFter reversing :",alist)
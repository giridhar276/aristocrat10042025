'''
write a program to capture any filename from the keyboard and display its filename and extension seperately

Output:

Enter any filename:  abc.py

filename : abc
extension: py
'''

filename = input("Enter any filename :")
print("You entered :",filename)
if "." in filename :
    data = filename.split(".")
    print("Filename :",data[0])
    print("Extension :",data[1])
else:
    print("input is not the proper filename")
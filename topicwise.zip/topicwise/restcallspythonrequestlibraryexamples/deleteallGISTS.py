import requests
import json
r = requests.get('https://api.github.com/users/giridhar276/gists', auth=('giridhar276','8f7dd3f65c4c60f1b57f8ec8f15b692fe28d70cb'))
print(r.status_code)


info = json.loads(r.text)
for item in info:
    gid = item["id"]
    url = server + "/gists/" + gid
    r1 = requests.delete(url, auth=HTTPBasicAuth(user,'8f7dd3f65c4c60f1b57f8ec8f15b692fe28d70cb'))
    print(r1)
    print(r1.text)
    


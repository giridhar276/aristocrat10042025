import requests
import json

####
# inputs
####
username = 'giridhar276@gmail.com'

# from https://github.com/user/settings/tokens
token = '2934dfe9ab555681eef4b7e41e2fac313607eb75'

repos_url = 'https://api.github.com/users/giridhar276'

# create a re-usable session object with the user creds in-built
gh_session = requests.Session()
gh_session.auth = (username, token)

gitreader = gh_session.get(repos_url)

# get the list of repos belonging to me
repos = json.loads(gitreader.text)

# print the repo names
for repo in repos:
    print(repo )
    print(repos[repo])
    print("------------")

